#!/usr/bin/env python
from importlib import import_module
import os
from flask import Flask, render_template, Response
from RPi import GPIO
#from pizypwm import *
from flask import request
import json
# import camera driver
if os.environ.get('CAMERA'):
    Camera = import_module('camera_' + os.environ['CAMERA']).Camera
else:
    from camera import Camera

gazul = 0
naklonv = 10

class PWM:
    def __init__( self, pin ):
        self.pin = pin

    def set( self, value ):
        cmd = 'echo "%d=%.2f" > /dev/pi-blaster' % ( self.pin, value )
        os.system(cmd)




app = Flask(__name__, static_folder='static', static_url_path='/static')


@app.route('/')
def index():
    """Video streaming home page."""
    return render_template('index.html')


def gen(camera):
    """Video streaming generator function."""
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')







@app.route('/fire',methods=['GET', 'POST'])
def fire():

     gazdv =  request.args['fire']
     g = float(gazdv)

     fireb = PWM(4)
     
     fireb.set(g)
     print g

     return 'FIRE'






@app.route('/stop',methods=['GET', 'POST'])
def stop():



     return 'STOP'


@app.route('/gazd',methods=['GET', 'POST'])
def gazd():

     gazdv =  request.args['gazd']
     g = float(gazdv)
     blasgaz = PWM(18)
     blasgaz.set(g)
     print g
     return 'GAZD'


@app.route('/naklon',methods=['GET', 'POST'])
def naklon():

     gazdv =  request.args['naklon']
     g = float(gazdv)
     naklonb = PWM(17)
     naklonb.set(g)
     print g
     return 'NAKLON'
@app.route('/pitch',methods=['GET', 'POST'])
def pitch():

     gazdv =  request.args['pitch']
     g = float(gazdv)
     pitchb = PWM(27)
     pitchb.set(g)
     print g
     return 'PITCH'
@app.route('/rotate',methods=['GET', 'POST'])
def rotate():

     rotate =  request.args['rotate']
     g = float(rotate)
     rotateb = PWM(22)
     rotateb.set(g)
     
     print g
     return 'ROTATE'


@app.route('/rezhimi',methods=['GET', 'POST'])
def rezhimi():

     rezhim =  request.args['rezhimi']
     g = float(rezhim)
     rezhimib = PWM(23)
     rezhimib.set(g)

     print g
     return 'REZHIMI'




if __name__ == '__main__':
    app.run(host='0.0.0.0', threaded=True)
